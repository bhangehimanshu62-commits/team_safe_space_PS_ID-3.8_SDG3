import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-6849b716/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-6849b716/signup", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );
    
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    
    if (error) {
      console.log(`Signup error for ${email}: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Unexpected signup error: ${error}`);
    return c.json({ error: 'Failed to sign up' }, 500);
  }
});

// Get patient health records
app.get("/make-server-6849b716/health-records", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );
    
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      console.log('Missing access token in health-records request');
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user?.id) {
      console.log(`Auth error while fetching health records: ${authError?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    // Fetch health records from KV store
    const records = await kv.getByPrefix(`health_record:${user.id}:`);
    
    console.log(`Fetched ${records?.length || 0} records for user ${user.id}`);
    
    return c.json({ records: records || [] });
  } catch (error) {
    console.log(`Error fetching health records: ${error}`);
    return c.json({ error: 'Failed to fetch health records', details: String(error) }, 500);
  }
});

// Sync with EMR systems - FHIR-based integration
app.post("/make-server-6849b716/sync-emr", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );
    
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user?.id) {
      console.log(`Auth error during EMR sync: ${authError?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { emrSystem, patientId } = await c.req.json();
    
    // In a real implementation, this would call actual EMR FHIR APIs
    // For now, we'll simulate the data aggregation
    const mockEmrData = {
      system: emrSystem,
      patient: patientId,
      lastSync: new Date().toISOString(),
      records: [
        {
          id: `${emrSystem}-${Date.now()}-1`,
          type: 'Observation',
          code: { text: 'Blood Pressure' },
          value: '120/80 mmHg',
          effectiveDateTime: new Date().toISOString(),
          source: emrSystem,
        },
        {
          id: `${emrSystem}-${Date.now()}-2`,
          type: 'Condition',
          code: { text: 'Hypertension' },
          onsetDateTime: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString(),
          source: emrSystem,
        },
        {
          id: `${emrSystem}-${Date.now()}-3`,
          type: 'MedicationStatement',
          medication: { text: 'Lisinopril 10mg' },
          effectivePeriod: { start: new Date().toISOString() },
          source: emrSystem,
        },
      ],
    };
    
    // Store aggregated data in KV
    await kv.set(`health_record:${user.id}:${emrSystem}`, mockEmrData);
    
    return c.json({ 
      success: true, 
      message: `Synced ${mockEmrData.records.length} records from ${emrSystem}`,
      records: mockEmrData.records 
    });
  } catch (error) {
    console.log(`Error syncing EMR data: ${error}`);
    return c.json({ error: 'Failed to sync EMR data' }, 500);
  }
});

// Get aggregated health summary
app.get("/make-server-6849b716/health-summary", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );
    
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user?.id) {
      console.log(`Auth error while fetching health summary: ${authError?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    // Fetch all health records
    const allRecords = await kv.getByPrefix(`health_record:${user.id}:`);
    
    // Aggregate data from all EMR systems
    const observations: any[] = [];
    const conditions: any[] = [];
    const medications: any[] = [];
    
    allRecords.forEach((record: any) => {
      record.records?.forEach((item: any) => {
        if (item.type === 'Observation') observations.push(item);
        else if (item.type === 'Condition') conditions.push(item);
        else if (item.type === 'MedicationStatement') medications.push(item);
      });
    });
    
    return c.json({
      summary: {
        totalRecords: observations.length + conditions.length + medications.length,
        observations: observations.length,
        conditions: conditions.length,
        medications: medications.length,
        lastSync: allRecords[0]?.lastSync || null,
      },
      observations,
      conditions,
      medications,
    });
  } catch (error) {
    console.log(`Error fetching health summary: ${error}`);
    return c.json({ error: 'Failed to fetch health summary' }, 500);
  }
});

Deno.serve(app.fetch);