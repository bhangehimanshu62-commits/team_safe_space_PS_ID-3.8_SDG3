
  # Universal Health Record Aggregator

  This is a code bundle for Universal Health Record Aggregator. The original project is available at https://www.figma.com/design/UqA5lWblC5YR5qW6U6oEtJ/Universal-Health-Record-Aggregator.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  