import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { ActivityIcon, HeartPulseIcon, PillIcon, HospitalIcon, RefreshCwIcon, LogOutIcon } from 'lucide-react';
import { toast } from 'sonner';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface DashboardProps {
  accessToken: string;
  userName: string;
  onLogout: () => void;
}

interface HealthSummary {
  summary: {
    totalRecords: number;
    observations: number;
    conditions: number;
    medications: number;
    lastSync: string | null;
  };
  observations: any[];
  conditions: any[];
  medications: any[];
}

const EMR_SYSTEMS = [
  { id: 'epic', name: 'Epic EMR' },
  { id: 'cerner', name: 'Cerner' },
  { id: 'athenahealth', name: 'athenahealth' },
  { id: 'allscripts', name: 'Allscripts' },
];

export function Dashboard({ accessToken, userName, onLogout }: DashboardProps) {
  const [healthSummary, setHealthSummary] = useState<HealthSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  const fetchHealthSummary = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-6849b716/health-summary`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Health summary error response:', errorData);
        throw new Error(errorData.error || 'Failed to fetch health summary');
      }

      const data = await response.json();
      console.log('Health summary fetched successfully:', data);
      setHealthSummary(data);
    } catch (error) {
      console.error('Error fetching health summary:', error);
      toast.error(`Failed to fetch health records: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const syncEMR = async (emrSystem: string) => {
    setIsSyncing(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-6849b716/sync-emr`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            emrSystem,
            patientId: `PATIENT-${Date.now()}`,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error('EMR sync error response:', errorData);
        throw new Error(errorData.error || 'Failed to sync EMR data');
      }

      const data = await response.json();
      console.log('EMR sync successful:', data);
      toast.success(data.message);
      await fetchHealthSummary();
    } catch (error) {
      console.error('Error syncing EMR:', error);
      toast.error(`Failed to sync EMR data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    fetchHealthSummary();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600">Loading health records...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <HospitalIcon className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Health Record Aggregator</h1>
                <p className="text-sm text-gray-600">Welcome, {userName}</p>
              </div>
            </div>
            <Button variant="outline" onClick={onLogout}>
              <LogOutIcon className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Records</CardTitle>
              <ActivityIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthSummary?.summary.totalRecords || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Observations</CardTitle>
              <HeartPulseIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthSummary?.summary.observations || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conditions</CardTitle>
              <ActivityIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthSummary?.summary.conditions || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Medications</CardTitle>
              <PillIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthSummary?.summary.medications || 0}</div>
            </CardContent>
          </Card>
        </div>

        {/* EMR Sync */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Connect EMR Systems</CardTitle>
            <CardDescription>
              Sync your health records from different hospital EMR systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {EMR_SYSTEMS.map((system) => (
                <Button
                  key={system.id}
                  variant="outline"
                  onClick={() => syncEMR(system.id)}
                  disabled={isSyncing}
                  className="h-auto py-4 flex flex-col items-center"
                >
                  <RefreshCwIcon className={`h-6 w-6 mb-2 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span className="font-medium">{system.name}</span>
                  <span className="text-xs text-muted-foreground mt-1">Click to sync</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Health Records */}
        <Card>
          <CardHeader>
            <CardTitle>Your Health Records</CardTitle>
            <CardDescription>
              Aggregated data from all connected EMR systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="observations" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="observations">Observations</TabsTrigger>
                <TabsTrigger value="conditions">Conditions</TabsTrigger>
                <TabsTrigger value="medications">Medications</TabsTrigger>
              </TabsList>

              <TabsContent value="observations" className="space-y-4 mt-4">
                {healthSummary?.observations.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No observations found. Sync with an EMR system to get started.</p>
                ) : (
                  healthSummary?.observations.map((obs) => (
                    <div key={obs.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{obs.code.text}</h3>
                        <Badge variant="outline">{obs.source}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">Value: {obs.value}</p>
                      <p className="text-xs text-gray-500">
                        Date: {new Date(obs.effectiveDateTime).toLocaleDateString()}
                      </p>
                    </div>
                  ))
                )}
              </TabsContent>

              <TabsContent value="conditions" className="space-y-4 mt-4">
                {healthSummary?.conditions.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No conditions found. Sync with an EMR system to get started.</p>
                ) : (
                  healthSummary?.conditions.map((condition) => (
                    <div key={condition.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{condition.code.text}</h3>
                        <Badge variant="outline">{condition.source}</Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        Onset: {new Date(condition.onsetDateTime).toLocaleDateString()}
                      </p>
                    </div>
                  ))
                )}
              </TabsContent>

              <TabsContent value="medications" className="space-y-4 mt-4">
                {healthSummary?.medications.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No medications found. Sync with an EMR system to get started.</p>
                ) : (
                  healthSummary?.medications.map((med) => (
                    <div key={med.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{med.medication.text}</h3>
                        <Badge variant="outline">{med.source}</Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        Started: {new Date(med.effectivePeriod.start).toLocaleDateString()}
                      </p>
                    </div>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}