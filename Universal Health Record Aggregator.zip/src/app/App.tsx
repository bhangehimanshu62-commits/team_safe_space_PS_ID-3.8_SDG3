import { useState, useEffect } from 'react';
import { supabase } from '@/app/lib/supabase';
import { AuthForm } from '@/app/components/AuthForm';
import { Dashboard } from '@/app/components/Dashboard';
import { Toaster, toast } from 'sonner';
import { projectId, publicAnonKey } from '/utils/supabase/info';

export default function App() {
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    checkSession();
  }, []);

  const checkSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error('Session error:', error);
      }
      
      if (session?.access_token) {
        setAccessToken(session.access_token);
        setUserName(session.user?.user_metadata?.name || session.user?.email || 'User');
      }
    } catch (error) {
      console.error('Error checking session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast.error(error.message);
        return;
      }

      if (session?.access_token) {
        setAccessToken(session.access_token);
        setUserName(session.user?.user_metadata?.name || session.user?.email || 'User');
        toast.success('Successfully logged in');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Failed to login');
    }
  };

  const handleSignup = async (email: string, password: string, name: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-6849b716/signup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ email, password, name }),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        toast.error(data.error || 'Failed to sign up');
        return;
      }

      toast.success('Account created successfully! Please login.');
    } catch (error) {
      console.error('Signup error:', error);
      toast.error('Failed to sign up');
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setAccessToken(null);
      setUserName('');
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Failed to logout');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Toaster richColors position="top-right" />
      {accessToken ? (
        <Dashboard
          accessToken={accessToken}
          userName={userName}
          onLogout={handleLogout}
        />
      ) : (
        <AuthForm onLogin={handleLogin} onSignup={handleSignup} />
      )}
    </>
  );
}